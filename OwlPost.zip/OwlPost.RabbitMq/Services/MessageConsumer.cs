﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RabbitMQ.Client.Events;
using System.Text;
using System.Text.Json;

namespace OwlPost.RabbitMq.Services;

internal sealed class MessageConsumer : BackgroundService
{
    #region Fields and Ctor

    private readonly IAppLogger<MessageConsumer> _logger;
    private readonly IChannelManager _channelManager;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly RabbitMqOptions _options;
    private readonly uint _prefetchSize;
    private readonly ushort _prefetchCount;
    private readonly IDictionary<string, IChannel> _channelsPerQueue;
    private readonly ISerializer _serializer;

    internal MessageConsumer(
        IAppLogger<MessageConsumer> logger,
        IChannelManager channelManager,
        IOptions<RabbitMqOptions> options,
        IServiceScopeFactory scopeFactory, ISerializer serializer)
    {
        _logger = logger;
        _channelManager = channelManager;
        _scopeFactory = scopeFactory;
        _serializer = serializer;
        _options = options.Value;

        _channelsPerQueue = new Dictionary<string, IChannel>(_options.Queue.Count);
        _prefetchSize = _options.Channel.PrefetchSize;
        _prefetchCount = _options.Channel.PrefetchCount;
    }

    #endregion


    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        foreach (var queue in _options.Queue)
        {
            _channelsPerQueue.Add(queue.Name, await _channelManager.GetChannelAsyncForConsume());
        }

        #region Consume Messages Action

        var tasks = _options.Queue
            .Select(queue => ConsumeQueue(queue.Name, ct));

        await Task.WhenAll(tasks);


        #endregion

        await Task.Delay(Timeout.InfiniteTimeSpan, ct);
    }


    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        await Task.WhenAll(
            _channelsPerQueue.Values.Select(async channel =>
            {
                try
                {
                    if (channel.IsOpen)
                        await channel.CloseAsync(cancellationToken);

                    await channel.DisposeAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex,
                        "Error closing RabbitMQ channel");
                }
            }));

        await base.StopAsync(cancellationToken);
    }


    #region Private Methods

    private async Task ConsumeQueue(string queueName, CancellationToken ct)
    {
        var channel = _channelsPerQueue[queueName];

        if (channel is null || !channel.IsOpen)
            throw new Exception("Channel is not accessible");

        await channel.BasicQosAsync(
            prefetchSize: _prefetchSize,
            prefetchCount: _prefetchCount,
            global: false,
            ct);

        var consumer = new AsyncEventingBasicConsumer(channel);

        AddReceivingEvent(queueName, consumer, channel);

        await channel.BasicConsumeAsync(
            queue: queueName,
            autoAck: false,
            consumer: consumer,
            consumerTag: $"consumer-{Environment.MachineName}-{queueName}",
            cancellationToken: ct);
    }

    private void AddReceivingEvent(string queueName, AsyncEventingBasicConsumer consumer, IChannel channel)
    {
        consumer.ReceivedAsync += async (sender, ea) =>
        {
            var consumerChannel = ((AsyncEventingBasicConsumer)sender).Channel;

            try
            {
                var body = ea.Body.ToArray();
                var data = _serializer.Deserialize<object>(body);

                _logger.LogDebug(
                    "Message received from {Queue}",
                    data);

                await consumerChannel.BasicAckAsync(
                    deliveryTag: ea.DeliveryTag,
                    multiple: false,
                    CancellationToken.None);
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "Error processing message from queue {Queue}. Exchange: {Exchange}, RoutingKey: {RoutingKey}",
                    queueName,
                    ea.Exchange,
                    ea.RoutingKey);

                try
                {
                    await channel.BasicNackAsync(
                        deliveryTag: ea.DeliveryTag,
                        multiple: false,
                        requeue: false,
                        cancellationToken: CancellationToken.None);
                }
                catch (Exception nackEx)
                {
                    _logger.LogError(
                        nackEx,
                        "Failed to nack message from queue {Queue}",
                        queueName);
                }
            }
        };
    }

    private IMessageBusRequest GetMessage(byte[] serializedData, string exchange )
    {
        if (exchange.Equals("0", StringComparison.CurrentCultureIgnoreCase))
        {
            return _serializer.Deserialize<MessageBusCreateRoomRequest>(serializedData);
        }
        if (exchange.Equals("1", StringComparison.CurrentCultureIgnoreCase))
        {
            return _serializer.Deserialize<MessageBusDeleteMessageRequest>(serializedData);

        }
        if (exchange.Equals("2", StringComparison.CurrentCultureIgnoreCase))
        {
            return _serializer.Deserialize<MessageBusEditMessageRequest>(serializedData);

        }
        else
        {
            throw new Exception();
        }
    }

    #endregion

}
